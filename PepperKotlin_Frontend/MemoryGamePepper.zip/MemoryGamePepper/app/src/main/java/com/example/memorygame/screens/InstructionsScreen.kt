package com.example.memorygame.screens

@Composable
fun InstructionsScreen() {
    Text("Spielanleitung/Einstellungen (kommt noch)")
}
