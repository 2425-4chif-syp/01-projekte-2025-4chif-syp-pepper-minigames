package com.example.memorygame.menu

@Composable
fun MainMenuScreen(navController: NavHostController) {
    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Memory Game") })
        }
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Button(onClick = { navController.navigate("grid_selection") }) {
                Text("Spiel starten")
            }
            Spacer(modifier = Modifier.height(16.dp))
            Button(onClick = { navController.navigate("high_scores") }) {
                Text("High Scores anzeigen")
            }
            Spacer(modifier = Modifier.height(16.dp))
            Button(onClick = { navController.navigate("instructions") }) {
                Text("Spielanleitung/Einstellungen")
            }
        }
    }
}
