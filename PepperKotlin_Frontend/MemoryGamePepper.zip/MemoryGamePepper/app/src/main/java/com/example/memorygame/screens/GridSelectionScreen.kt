package com.example.memorygame.screens

@Composable
fun GridSelectionScreen(navController: NavHostController) {
    Text("Grid-Auswahl (kommt noch)")
}
