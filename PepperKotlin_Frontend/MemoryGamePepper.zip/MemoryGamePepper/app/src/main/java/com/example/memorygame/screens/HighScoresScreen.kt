package com.example.memorygame.screens

@Composable
fun HighScoresScreen() {
    Text("High Scores (kommt noch)")
}
